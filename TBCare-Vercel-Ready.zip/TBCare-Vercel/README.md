# TBCare — Vercel Ready

## Deploy cepat ke Vercel
1. Upload folder project ini ke GitHub sebagai repository baru.
2. Buka https://vercel.com/new
3. Import repository TBCare.
4. Framework Preset: Next.js (otomatis).
5. Klik **Deploy**.

Tidak membutuhkan environment variable untuk versi demo ini.

## Lokal
```bash
npm install
npm run dev
```
Buka http://localhost:3000

## Catatan
AI pada versi ini adalah demo lokal berbasis respons terprogram, bukan koneksi ke model AI eksternal. Untuk produksi, sambungkan endpoint AI melalui server-side API dan simpan secret hanya di environment variables Vercel.
