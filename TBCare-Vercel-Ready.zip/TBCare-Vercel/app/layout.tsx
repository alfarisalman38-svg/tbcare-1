import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "TBCare — Tuberculosis Education & AI Consultation",
  description: "Platform edukasi interaktif tentang tuberkulosis.",
  keywords: ["TBC", "tuberkulosis", "Mycobacterium tuberculosis", "edukasi kesehatan"]
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="id">
      <body>{children}</body>
    </html>
  );
}
