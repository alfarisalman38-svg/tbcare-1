/* TBCare — ready for Vercel deployment */
"use client";

import { Canvas, useFrame } from "@react-three/fiber";
import { motion } from "framer-motion";
import { useMemo, useRef, useState } from "react";
import type { Mesh } from "three";

const symptoms = ["Batuk berkepanjangan", "Demam", "Berkeringat malam", "Berat badan turun", "Mudah lelah", "Nafsu makan turun", "Batuk berdarah", "Sesak napas"];
const quiz = [
  ["TBC disebabkan oleh...", ["Virus", "Bakteri", "Jamur", "Alergi"], 1, "TBC disebabkan oleh bakteri Mycobacterium tuberculosis."],
  ["Penularan TBC paru aktif terutama melalui...", ["Makanan", "Air", "Udara", "Sentuhan kulit"], 2, "Bakteri dapat menyebar melalui udara ketika penderita TBC paru aktif batuk, berbicara, atau bersin."],
  ["TBC paling sering menyerang...", ["Paru-paru", "Kulit", "Tulang saja", "Mata"], 0, "Paru-paru adalah organ yang paling sering terkena."],
  ["Gejala saja dapat memastikan diagnosis TBC.", ["Benar", "Salah"], 1, "Gejala dapat memiliki banyak penyebab. Pemeriksaan tenaga kesehatan diperlukan untuk diagnosis."],
  ["Salah satu langkah pencegahan adalah...", ["Mengabaikan batuk", "Ventilasi baik", "Berbagi alat makan", "Menghentikan obat sendiri"], 1, "Ventilasi dan etika batuk membantu mengurangi risiko penularan."],
  ["TBC dapat disembuhkan dengan pengobatan yang tepat dan teratur.", ["Benar", "Salah"], 0, "Pengobatan TBC perlu diikuti sesuai arahan tenaga kesehatan."],
  ["Saat pengobatan, obat boleh dihentikan sendiri ketika sudah merasa sehat.", ["Benar", "Salah"], 1, "Jangan menghentikan pengobatan tanpa arahan tenaga kesehatan."],
  ["Batuk berdarah dalam jumlah banyak atau sesak berat membutuhkan...", ["Menunggu beberapa minggu", "Pertolongan medis segera", "Olahraga berat", "Tidak perlu tindakan"], 1, "Kondisi tersebut memerlukan pertolongan medis segera."],
  ["TBC bukan...", ["Penyakit infeksi", "Penyakit yang dapat diobati", "Disebabkan M. tuberculosis", "Penyakit yang selalu menular lewat sentuhan"], 3, "TBC tidak terutama menyebar melalui sentuhan biasa."],
  ["Sumber informasi medis yang baik antara lain...", ["WHO", "Kemenkes RI", "Tenaga kesehatan", "Semua benar"], 3, "Gunakan sumber kesehatan tepercaya dan tenaga kesehatan."],
];

function Bacterium() {
  const group = useRef<any>(null);
  useFrame((_, delta) => { if (group.current) group.current.rotation.y += delta * 0.35; });
  const rods = useMemo(() => Array.from({length: 34}, (_, i) => ({
    p: [(Math.sin(i*1.7)*2.4), (Math.cos(i*2.1)*1.45), (Math.sin(i*2.8)*1.35)] as [number,number,number],
    r: [i*.43, i*.27, i*.19] as [number,number,number]
  })), []);
  return <group ref={group}>{rods.map((r,i)=><mesh key={i} position={r.p} rotation={r.r}><capsuleGeometry args={[0.10,0.72,6,10]}/><meshStandardMaterial color="#25d8ff" emissive="#007d9d" emissiveIntensity={1.5} roughness={.28}/></mesh>)}</group>;
}

export default function Home() {
  const [dark, setDark] = useState(true);
  const [checked, setChecked] = useState<string[]>([]);
  const [q, setQ] = useState(0);
  const [score, setScore] = useState(0);
  const [done, setDone] = useState(false);
  const [messages, setMessages] = useState([{from:"ai", text:"Halo, saya TBCare AI. Saya dapat membantu menjelaskan informasi umum tentang tuberkulosis. Saya bukan dokter dan tidak dapat mendiagnosis atau meresepkan obat."}]);
  const [input, setInput] = useState("");

  const ask = () => {
    if (!input.trim()) return;
    const text = input.trim();
    const lower = text.toLowerCase();
    let reply = "TBC adalah penyakit infeksi yang disebabkan oleh bakteri Mycobacterium tuberculosis. Jika Anda memiliki keluhan atau kekhawatiran tentang TBC, sebaiknya konsultasikan dengan tenaga kesehatan.";
    if (lower.includes("menular") || lower.includes("penular")) reply = "TBC paru aktif terutama dapat menular melalui udara ketika penderita batuk, berbicara, atau bersin. Ventilasi yang baik dan evaluasi kesehatan membantu mengurangi risiko.";
    if (lower.includes("gejala")) reply = "Gejala yang dapat muncul antara lain batuk berkepanjangan, demam, keringat malam, penurunan berat badan, dan lelah. Gejala saja tidak cukup untuk memastikan diagnosis.";
    if (lower.includes("obat") || lower.includes("sembuh")) reply = "TBC dapat disembuhkan dengan pengobatan yang tepat dan teratur. Jangan memulai, mengubah, atau menghentikan obat tanpa arahan tenaga kesehatan.";
    setMessages(m => [...m, {from:"user", text}, {from:"ai", text:reply}]);
    setInput("");
  };

  const toggleSymptom = (s:string) => setChecked(c => c.includes(s) ? c.filter(x=>x!==s) : [...c,s]);
  const urgent = checked.includes("Batuk berdarah") || checked.includes("Sesak napas");

  return <main className={dark ? "dark" : ""}>
    <nav className="nav">
      <a className="brand" href="#home"><span className="logo">✚</span>TBCare</a>
      <div className="links">{["TBC","Bakteri","Penularan","Gejala","Pencegahan","Pengobatan","Quiz","AI"].map(x=><a key={x} href={"#"+x.toLowerCase()}>{x}</a>)}</div>
      <div className="nav-actions"><button onClick={()=>setDark(!dark)} aria-label="Ganti tema">{dark?"☼":"☾"}</button><a className="cta small" href="#ai">Konsultasi AI</a></div>
    </nav>

    <section id="home" className="hero">
      <div className="hero-copy">
        <span className="eyebrow">TUBERCULOSIS EDUCATION • AI ASSISTANT</span>
        <h1>KENALI BAKTERI.<br/><em>PAHAMI TBC.</em><br/>LINDUNGI DIRI.</h1>
        <p>Pelajari Tuberkulosis melalui visualisasi interaktif, edukasi kesehatan, dan teknologi AI.</p>
        <div className="actions"><a className="cta" href="#bakteri">Mulai Eksplorasi →</a><a className="ghost" href="#ai">Konsultasi AI</a></div>
      </div>
      <div className="scene"><div className="hud">MICROSCOPE MODE<br/><b>M. TUBERCULOSIS</b></div><Canvas camera={{position:[0,0,7], fov:45}}><ambientLight intensity={1.2}/><pointLight position={[5,5,5]} intensity={30} color="#32dfff"/><Bacterium/></Canvas></div>
    </section>

    <section id="tbc" className="section intro">
      <div><span className="eyebrow">01 / DASAR</span><h2>Apa itu <span>TBC?</span></h2></div>
      <div className="panel"><p>Tuberkulosis adalah penyakit infeksi yang disebabkan oleh bakteri <i>Mycobacterium tuberculosis</i>. Penyakit ini paling sering menyerang paru-paru, tetapi dapat menyerang organ lain.</p><div className="flow"><b>BAKTERI</b><span>→</span><b>TUBUH</b><span>→</span><b>PARU-PARU</b></div></div>
    </section>

    <section id="bakteri" className="section dark-section">
      <span className="eyebrow">02 / EKSPLORASI 3D</span><h2>Kenali <span>Mycobacterium tuberculosis</span></h2>
      <div className="explore"><div className="big-scene"><Canvas camera={{position:[0,0,8], fov:50}}><ambientLight intensity={1}/><pointLight position={[4,4,5]} intensity={40} color="#1edfff"/><Bacterium/></Canvas></div><div className="info-card"><span className="tag">BACTERIA</span><h3>Mycobacterium tuberculosis</h3><p>Bakteri penyebab tuberkulosis. Bentuknya menyerupai batang dan memiliki karakteristik dinding sel yang khas.</p><ul><li>Nama: <b>M. tuberculosis</b></li><li>Jenis: <b>Bakteri</b></li><li>Peran: <b>Penyebab TBC</b></li></ul></div></div>
    </section>

    <section id="penularan" className="section">
      <span className="eyebrow">03 / TRANSMISI</span><h2>Bagaimana TBC <span>menular?</span></h2>
      <div className="transmission"><div className="person">😷<small>TBC paru aktif</small></div><div className="air">••• → → → •••</div><div className="person">🫁<small>Menghirup udara</small></div></div>
      <p className="center">TBC paru aktif terutama menyebar melalui udara ketika seseorang batuk, berbicara, atau bersin.</p>
    </section>

    <section id="gejala" className="section dark-section">
      <span className="eyebrow">04 / KENALI TANDA</span><h2>Gejala yang perlu <span>diperhatikan</span></h2>
      <div className="grid">{symptoms.map((s,i)=><div className="symptom" key={s}><span>0{i+1}</span><b>{s}</b></div>)}</div>
      <div className="checker panel"><h3>Symptom Checker</h3><p>Pilih gejala yang sedang Anda alami untuk mendapatkan informasi awal. Ini bukan diagnosis.</p><div className="checks">{symptoms.map(s=><label key={s}><input type="checkbox" checked={checked.includes(s)} onChange={()=>toggleSymptom(s)}/>{s}</label>)}</div><div className="result"><b>Hasil Informasi Awal</b><p>{checked.length ? `Anda memilih ${checked.length} gejala. Gejala dapat memiliki banyak penyebab; konsultasikan dengan tenaga kesehatan untuk penilaian lebih lanjut.` : "Belum ada gejala yang dipilih."}</p>{urgent && <strong>⚠ Jika sesak berat atau batuk berdarah dalam jumlah banyak, cari pertolongan medis segera.</strong>}</div></div>
    </section>

    <section id="pencegahan" className="section">
      <span className="eyebrow">05 / PENCEGAHAN</span><h2>Kurangi risiko dengan <span>langkah sederhana</span></h2>
      <div className="timeline">{["Ventilasi dan sirkulasi udara baik","Etika batuk dan bersin","Perlindungan sesuai kondisi dan anjuran kesehatan","Periksa jika memiliki gejala atau kontak erat","Ikuti pengobatan sampai selesai sesuai arahan"].map((x,i)=><div key={x}><b>0{i+1}</b><span>{x}</span></div>)}</div>
    </section>

    <section id="pengobatan" className="section dark-section">
      <span className="eyebrow">06 / PENGOBATAN</span><h2>Dapat disembuhkan dengan <span>pengobatan tepat</span></h2>
      <div className="treatment">{["Pemeriksaan","Diagnosis","Pengobatan","Tindak lanjut","Selesai"].map((x,i)=><div key={x}><span>{i+1}</span><b>{x}</b></div>)}</div>
      <p className="note">TBC dapat disembuhkan dengan pengobatan yang tepat dan teratur. Jangan menghentikan pengobatan atau mengubah obat tanpa arahan tenaga kesehatan.</p>
    </section>

    <section id="quiz" className="section">
      <span className="eyebrow">07 / KNOWLEDGE CHECK</span><h2>Uji <span>pengetahuanmu</span></h2>
      {!done ? <div className="quiz panel"><div className="progress">Pertanyaan {q+1} / {quiz.length}</div><h3>{quiz[q][0] as string}</h3><div className="answers">{(quiz[q][1] as string[]).map((a,i)=><button key={a} onClick={()=>{if(i===quiz[q][2]) setScore(s=>s+1); if(q+1===quiz.length)setDone(true); else setQ(x=>x+1)}}>{a}</button>)}</div></div> : <div className="quiz panel score"><b>QUIZ SELESAI</b><strong>{score} / {quiz.length}</strong><p>Pelajari kembali materi untuk memperkuat pemahaman.</p><button className="cta" onClick={()=>{setQ(0);setScore(0);setDone(false)}}>Ulangi Quiz</button></div>}
    </section>

    <section id="ai" className="section ai-section">
      <span className="eyebrow">08 / AI ASSISTANT</span><h2>TBCare <span>AI</span></h2>
      <div className="chat panel"><div className="messages">{messages.map((m,i)=><div key={i} className={m.from}>{m.text}</div>)}</div><div className="composer"><input value={input} onChange={e=>setInput(e.target.value)} onKeyDown={e=>e.key==="Enter"&&ask()} placeholder="Tanyakan tentang TBC..." /><button onClick={ask}>Kirim</button></div><p className="disclaimer">TBCare AI hanya memberikan informasi umum dan bukan pengganti dokter/tenaga kesehatan. Tidak dapat mendiagnosis, meresepkan obat, atau menentukan dosis. Untuk kondisi darurat, segera cari pertolongan medis.</p></div>
    </section>

    <section className="section sources">
      <span className="eyebrow">SUMBER</span><h2>Informasi berbasis <span>sumber tepercaya</span></h2>
      <div className="source-grid"><a href="https://www.who.int/health-topics/tuberculosis" target="_blank">WHO — Tuberculosis ↗</a><a href="https://tbindonesia.or.id/" target="_blank">Kemenkes RI / TB Indonesia ↗</a><a href="https://www.cdc.gov/tb/" target="_blank">CDC — Tuberculosis ↗</a></div>
    </section>

    <footer><div className="brand"><span className="logo">✚</span>TBCare</div><p>Kenali. Cegah. Periksa. Obati.</p><small>Untuk edukasi kesehatan. Bukan alat diagnosis.</small></footer>
    <div className="mobile-nav"><a href="#home">⌂</a><a href="#tbc">TBC</a><a href="#bakteri">◉</a><a href="#ai">AI</a><a href="#quiz">?</a></div>
  </main>;
}
